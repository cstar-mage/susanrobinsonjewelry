<?php 
class Mage_Uploadtool_Helper_Data extends Mage_Core_Helper_Abstract
{

	public function diamondSettings($field)
	{
		$uploadtool_settings = Mage::getSingleton("core/resource")->getTableName('uploadtool_settings');

		$read = Mage::getSingleton( 'core/resource' )->getConnection( 'core_read' );
		//$write = Mage::getSingleton( 'core/resource' )->getConnection( 'core_write' );
		
		$query = "select * from `$uploadtool_settings` where `field` = '".$field."'";
		$result = $read->query( $query );
		
		while ( $row = $result->fetch() ) {
			return $row['value'];
		}
	}
	
}